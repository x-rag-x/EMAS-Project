// ═══════════════════════════════════════════════════════
//  EAMS — Node.js / Express API Server
// ═══════════════════════════════════════════════════════
const dns = require('dns');
dns.setDefaultResultOrder('ipv4first');
dns.setServers(['8.8.8.8', '8.8.4.4']);

require('dotenv').config();

const express    = require('express');
const mongoose   = require('mongoose');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const cors       = require('cors');
const multer     = require('multer');
const XLSX       = require('xlsx');
const path       = require('path');
const crypto     = require('crypto');
const cfg        = require('./config');
const M          = require('./models');

const app    = express();
const upload = multer({ storage: multer.memoryStorage() });

// ── Middleware ────────────────────────────────────────
app.use(cors({ origin: process.env.NODE_ENV === 'production' ? true : cfg.CORS_ORIGIN, credentials: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '.')));

// ── MongoDB Connection ────────────────────────────────
mongoose.connect(cfg.MONGO_URI, { dbName: cfg.DB_NAME })
  .then(() => {
    console.log(`3/3 : ✅ MongoDB connected → ${cfg.DB_NAME}`);
    seedDefaults();
  })
  .catch(err => { console.error('3/3 :  ❌ MongoDB error:', err.message); process.exit(1); });

// ── Seed Defaults ─────────────────────────────────────
async function seedDefaults() {
  const adminExists = await M.User.findOne({ role: 'admin' });
  if (!adminExists) {
    const hash = await bcrypt.hash('admin123', cfg.BCRYPT_ROUNDS);
    await M.User.create({ name: 'Administrator', username: 'admin', password: hash, role: 'admin', mustChangePassword: true });

  }
  const teacherExists = await M.User.findOne({ role: 'teacher' });
  if (!teacherExists) {
    const plainPw = 'teacher123';
    const hash = await bcrypt.hash(plainPw, cfg.BCRYPT_ROUNDS);
    await M.User.create({ name: 'Default Teacher', username: 'teacher', password: hash, role: 'teacher', empId: 'EMP001', dept: 'Computer Science Engineering', desig: 'Assistant Professor', mustChangePassword: true });



  } else {
    // Verify existing teacher's hash is valid
    const testMatch = await bcrypt.compare('teacher123', teacherExists.password);

    if (!testMatch) {
      // Auto-reset teacher password if hash is broken
      const newHash = await bcrypt.hash('teacher123', cfg.BCRYPT_ROUNDS);
      await M.User.findByIdAndUpdate(teacherExists._id, { password: newHash, active: true, failedLogins: 0, lockedUntil: null });

    }
  }
  // Seed default settings
  const defaults = [
    { key: 'maintenance', value: { active: false, message: 'System under maintenance. Please try again later.', affectedRoles: ['teacher','student'], endTime: null, startedAt: null } },
    { key: 'institution', value: { name: 'Sri Shakthi Institute of Engineering and Technology', short: 'SSIET', address: 'Coimbatore, Tamil Nadu', email: '', phone: '' } },
    { key: 'academic', value: { year: '2025-26', sem: 'I', minAttendance: 75, workingDays: 5 } },
    { key: 'security', value: { maxLoginAttempts: 5, sessionTimeoutMins: 480, forcePwChange: true } },
    { key: 'special_delete_password', value: bcrypt.hashSync('987543210', 10) },
    { key: 'college_ips', value: ['127.0.0.1', '::1', '192.', '10.'] },
  ];
  for (const d of defaults) {
    const exists = await M.Settings.findOne({ key: d.key });
    if (!exists) await M.Settings.create(d);
  }
  // ── Migrate: patch any old maintenance record missing new fields (runs once, harmless after)
  await M.Settings.findOneAndUpdate(
    { key: 'maintenance', 'value.affectedRoles': { $exists: false } },
    { $set: { 'value.affectedRoles': ['teacher','student'], 'value.endTime': null, 'value.startedAt': null } }
  );

  // Log current credentials to DB (visible in Logs menu, not terminal)
  const adminUser2   = await M.User.findOne({ role: 'admin' });
  const teacherUser2 = await M.User.findOne({ role: 'teacher' });
  const adminPwSetting   = await M.Settings.findOne({ key: 'default_admin_pw' });
  const teacherPwSetting = await M.Settings.findOne({ key: 'default_teacher_pw' });
  const adminPw   = adminPwSetting?.value   || 'admin123';
  const teacherPw = teacherPwSetting?.value || 'teacher123';
  await M.Log.create({
    userId: adminUser2?._id, userName: 'SYSTEM', role: 'system',
    action: 'Server Started',
    details: `Admin: ${adminUser2?.username} | pwd: ${adminPw} || Teacher: ${teacherUser2?.username} | pwd: ${teacherPw}`,
    category: 'system', severity: 'info', ip: 'localhost',
    time: new Date()
  });
}

// ── Helper: log action to DB ──────────────────────────
async function logAction(userId, userName, role, action, details, category = 'general', severity = 'info', ip = '', sessionId = '') {
  try {
    await M.Log.create({
      userId, userName, role, action, details, category, severity,
      ip: ip || '', sessionId: sessionId || '',
      time: new Date()
    });
  } catch(e) {}
}

// ── Auth Middleware ───────────────────────────────────
async function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: 'No token' });
  const token = header.replace('Bearer ', '');
  try {
    req.user = jwt.verify(token, cfg.JWT_SECRET);
    // Session check (optional - JWT is primary auth)
    // session verification is best-effort only
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

function adminOnly(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ── Check maintenance mode ────────────────────────────
async function checkMaintenance(req, res, next) {
  const setting = await M.Settings.findOne({ key: 'maintenance' });
  if (setting?.value?.active && req.user?.role !== 'admin') {
    const v = setting.value;
    const affected = v.affectedRoles?.length ? v.affectedRoles : ['teacher','student'];
    if (affected.includes(req.user?.role)) {
      return res.status(503).json({
        error: v.message || 'System is under maintenance.',
        maintenance: true,
        message: v.message || 'System is under maintenance.',
        affectedRoles: affected,
        endTime: v.endTime || null,
        startedAt: v.startedAt || null,
      });
    }
  }
  next();
}

// ════════════════════════════════════════════════════════
//  AUTH ROUTES
// ════════════════════════════════════════════════════════

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password, role } = req.body;
    if (!username || !password || !role)
      return res.status(400).json({ error: 'username, password and role required' });


    const user = await M.User.findOne({ username: username.toLowerCase(), role, active: true });
    if (!user) {
      await logAction(null, username, role, 'Login Failed', 'User not found', 'security', 'warning', req.ip);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check account lock
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const mins = Math.ceil((user.lockedUntil - new Date()) / 60000);
      return res.status(429).json({ error: `Account locked. Try again in ${mins} minute(s).` });
    }


    const match = await bcrypt.compare(password, user.password);


    if (!match) {
      const security = await M.Settings.findOne({ key: 'security' });
      const maxAttempts = security?.value?.maxLoginAttempts || 5;
      const newFails = (user.failedLogins || 0) + 1;
      const updates = { failedLogins: newFails };
      if (newFails >= maxAttempts) {
        updates.lockedUntil = new Date(Date.now() + 15 * 60 * 1000); // lock 15 mins
        updates.failedLogins = 0;
        // Auto-enable maintenance if too many failures (possible attack)
        if (newFails >= maxAttempts * 2) {
          await M.Settings.findOneAndUpdate({ key: 'maintenance' }, { 'value.active': true });
          await logAction(user._id, user.name, role, 'Maintenance Auto-Enabled', 'Too many failed logins — possible attack', 'security', 'critical', req.ip);
        }
      }
      await M.User.findByIdAndUpdate(user._id, updates);
      await logAction(user._id, user.name, role, 'Login Failed', `Wrong password (attempt ${newFails})`, 'security', 'warning', req.ip);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check maintenance (non-admin blocked)
    if (role !== 'admin') {
      const maint = await M.Settings.findOne({ key: 'maintenance' });
      if (maint?.value?.active) {
        const v = maint.value;
        const affected = v.affectedRoles?.length ? v.affectedRoles : ['teacher','student'];
        if (affected.includes(role)) {
          return res.status(503).json({
            error: v.message || 'System under maintenance.',
            maintenance: true,
            message: v.message || 'System under maintenance.',
            affectedRoles: affected,
            endTime: v.endTime || null,
            startedAt: v.startedAt || null,
          });
        }
      }
    }

    // Reset failed logins

    await M.User.findByIdAndUpdate(user._id, { failedLogins: 0, lockedUntil: null, lastLogin: new Date(), $inc: { loginCount: 1 } });

    const token = jwt.sign(
      { _id: user._id, name: user.name, username: user.username, role: user.role, dept: user.dept, empId: user.empId, desig: user.desig },
      cfg.JWT_SECRET,
      { expiresIn: cfg.JWT_EXPIRES_IN }
    );

    // Create session record
    const sessionId = crypto.randomBytes(16).toString('hex');
    await M.Session.create({
      userId: user._id, username: user.username, role: user.role,
      token, ip: req.ip, userAgent: req.headers['user-agent'] || '',
    });

    await logAction(user._id, user.name, role, 'Login', `${role} logged in from ${req.ip}`, 'login', 'info', req.ip, sessionId);

    res.json({
      token, sessionId,
      mustChangePassword: user.mustChangePassword,
      user: {
        _id: user._id, name: user.name, role: user.role,
        dept: user.dept, empId: user.empId, desig: user.desig, email: user.email,
        isHOD: user.isHOD, isClassAdvisor: user.isClassAdvisor, advisorClassName: user.advisorClassName,
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/auth/logout', authMiddleware, async (req, res) => {
  try {
    const token = req.headers['authorization'].replace('Bearer ', '');
    await M.Session.findOneAndUpdate({ token }, { active: false });
    await logAction(req.user._id, req.user.name, req.user.role, 'Logout', 'User logged out', 'login', 'info', req.ip);
    res.json({ message: 'Logged out' });
  } catch(e) { res.json({ message: 'Logged out' }); }
});

app.post('/api/auth/change-password', authMiddleware, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await M.User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    const match = await bcrypt.compare(currentPassword, user.password);
    if (!match) return res.status(401).json({ error: 'Current password incorrect' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    user.password = await bcrypt.hash(newPassword, cfg.BCRYPT_ROUNDS);
    user.mustChangePassword = false;
    await user.save();
    await logAction(user._id, user.name, user.role, 'Password Changed', 'User changed their password', 'security', 'info', req.ip);
    res.json({ message: 'Password updated successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Verify session (called by control panel on open)
app.get('/api/auth/verify-session', authMiddleware, async (req, res) => {
  res.json({ valid: true, user: req.user });
});

// ════════════════════════════════════════════════════════
//  SETTINGS
// ════════════════════════════════════════════════════════

app.get('/api/settings', authMiddleware, adminOnly, async (req, res) => {
  const settings = await M.Settings.find({ key: { $ne: 'special_delete_password' } });
  const obj = {};
  settings.forEach(s => { obj[s.key] = s.value; });
  res.json(obj);
});

app.get('/api/settings/:key', authMiddleware, async (req, res) => {
  const s = await M.Settings.findOne({ key: req.params.key });
  if (!s) return res.status(404).json({ error: 'Setting not found' });
  if (req.params.key === 'special_delete_password') return res.status(403).json({ error: 'Forbidden' });
  res.json(s.value);
});

app.put('/api/settings/:key', authMiddleware, adminOnly, async (req, res) => {
  if (req.params.key === 'special_delete_password') return res.status(403).json({ error: 'Forbidden' });
  const s = await M.Settings.findOneAndUpdate(
    { key: req.params.key },
    { value: req.body.value, updatedBy: req.user.name },
    { new: true, upsert: true }
  );
  // Special detailed logging for maintenance changes
  if (req.params.key === 'maintenance') {
    const v = req.body.value || {};
    const prevSetting = await M.Settings.findOne({ key: 'maintenance' });
    const action = v.active ? 'Maintenance Mode Enabled' : 'Maintenance Mode Disabled';
    const affected = (v.affectedRoles || []).join(', ') || 'none';
    const endInfo = v.endTime ? ` | End: ${new Date(v.endTime).toLocaleString('en-IN')}` : '';
    const details = `Roles blocked: ${affected}${endInfo} | Msg: "${(v.message||'').slice(0,60)}"`;
    await logAction(req.user._id, req.user.name, req.user.role, action, details, 'maintenance', v.active ? 'warning' : 'info', req.ip);
  } else {
    await logAction(req.user._id, req.user.name, req.user.role, 'Settings Updated', `Key: ${req.params.key}`, 'settings', 'info', req.ip);
  }
  res.json(s.value);
});

// Verify special delete password
app.post('/api/settings/verify-delete-password', authMiddleware, adminOnly, async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });
  // Check admin password
  const user = await M.User.findById(req.user._id);
  const adminMatch = await bcrypt.compare(password, user.password);
  if (adminMatch) return res.json({ valid: true });
  // Check special password
  const setting = await M.Settings.findOne({ key: 'special_delete_password' });
  if (!setting) return res.status(403).json({ valid: false });
  const specialMatch = await bcrypt.compare(password, setting.value);
  if (specialMatch) return res.json({ valid: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'Delete Auth Failed', 'Wrong delete password attempt', 'security', 'warning', req.ip);
  res.status(403).json({ valid: false, error: 'Incorrect password' });
});

// ════════════════════════════════════════════════════════
//  DEPARTMENTS
// ════════════════════════════════════════════════════════

app.get('/api/departments', authMiddleware, async (req, res) => {
  res.json(await M.Department.find().sort({ name: 1 }));
});
app.post('/api/departments', authMiddleware, adminOnly, async (req, res) => {
  try {
    const dept = await M.Department.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Department Added', dept.name, 'data', 'info', req.ip);
    res.status(201).json(dept);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/departments/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const dept = await M.Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
    await logAction(req.user._id, req.user.name, req.user.role, 'Department Updated', dept.name, 'data', 'info', req.ip);
    res.json(dept);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.delete('/api/departments/:id', authMiddleware, adminOnly, async (req, res) => {
  const dept = await M.Department.findById(req.params.id).lean();
  if (dept) {
    await M.UndoLog.create({ collectionName: 'departments', label: `Department: ${dept.name}`,
      snapshot: dept, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.Department.findByIdAndDelete(req.params.id);
  }
  await logAction(req.user._id, req.user.name, req.user.role, 'Department Deleted', dept?.name || req.params.id, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// Alias
app.get('/api/depts', authMiddleware, async (req, res) => res.json(await M.Department.find().sort({ name: 1 })));
app.post('/api/depts', authMiddleware, adminOnly, async (req, res) => {
  try {
    const dept = await M.Department.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Department Added', dept.name, 'data', 'info', req.ip);
    res.status(201).json(dept);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/depts/:id', authMiddleware, adminOnly, async (req, res) => {
  const dept = await M.Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'Department Updated', dept?.name, 'data', 'info', req.ip);
  res.json(dept);
});
app.delete('/api/depts/:id', authMiddleware, adminOnly, async (req, res) => {
  const dept = await M.Department.findById(req.params.id).lean();
  if (dept) {
    await M.UndoLog.create({ collectionName: 'departments', label: `Department: ${dept.name}`,
      snapshot: dept, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.Department.findByIdAndDelete(req.params.id);
  }
  await logAction(req.user._id, req.user.name, req.user.role, 'Department Deleted', dept?.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  CLASSES
// ════════════════════════════════════════════════════════

app.get('/api/classes', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.deptId) filter.deptId = req.query.deptId;
  res.json(await M.Class.find(filter).sort({ name: 1 }));
});
app.post('/api/classes', authMiddleware, adminOnly, async (req, res) => {
  try {
    const cls = await M.Class.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Class Added', cls.name, 'data', 'info', req.ip);
    res.status(201).json(cls);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/classes/:id', authMiddleware, adminOnly, async (req, res) => {
  const cls = await M.Class.findByIdAndUpdate(req.params.id, req.body, { new: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'Class Updated', cls?.name, 'data', 'info', req.ip);
  res.json(cls);
});
app.delete('/api/classes/:id', authMiddleware, adminOnly, async (req, res) => {
  const cls = await M.Class.findById(req.params.id).lean();
  if (cls) {
    await M.UndoLog.create({ collectionName: 'classes', label: `Class: ${cls.name}`,
      snapshot: cls, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.Class.findByIdAndDelete(req.params.id);
  }
  await logAction(req.user._id, req.user.name, req.user.role, 'Class Deleted', cls?.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  STUDENTS
// ════════════════════════════════════════════════════════

app.get('/api/students', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.deptId)  filter.deptId  = req.query.deptId;
  if (req.query.classId) filter.classId = req.query.classId;
  if (req.query.section) filter.section = req.query.section;
  res.json(await M.Student.find(filter).sort({ name: 1 }));
});
app.get('/api/students/count', authMiddleware, async (req, res) => {
  res.json({ count: await M.Student.countDocuments() });
});
app.post('/api/students', authMiddleware, adminOnly, async (req, res) => {
  try {
    const stu = await M.Student.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Student Added', `${stu.name} (${stu.regNo})`, 'data', 'info', req.ip);
    res.status(201).json(stu);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/students/:id', authMiddleware, adminOnly, async (req, res) => {
  const stu = await M.Student.findByIdAndUpdate(req.params.id, req.body, { new: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'Student Updated', stu?.name, 'data', 'info', req.ip);
  res.json(stu);
});
app.delete('/api/students/:id', authMiddleware, adminOnly, async (req, res) => {
  const stu = await M.Student.findById(req.params.id).lean();
  if (stu) {
    await M.UndoLog.create({ collectionName: 'students', label: `Student: ${stu.name} (${stu.regNo})`,
      snapshot: stu, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.Student.findByIdAndDelete(req.params.id);
  }
  await logAction(req.user._id, req.user.name, req.user.role, 'Student Deleted', stu?.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ── Bulk Upload Students ─────────────────────────────
app.post('/api/students/bulk-upload', authMiddleware, adminOnly, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const workbook  = XLSX.read(req.file.buffer, { type: 'buffer' });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows      = XLSX.utils.sheet_to_json(worksheet);
    const VALID_COURSE_TYPES = ['UG','PG','M.E','M.TECH','MBA','MCA','B.E','B.TECH','BE','BTECH'];
    let added = 0, skipped = 0, errors = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const cv = (keys) => { for (const k of keys) { const found = Object.keys(row).find(r => r.toLowerCase().replace(/\s/g,'').includes(k.toLowerCase())); if (found) return String(row[found]).trim(); } return ''; };
      const name = cv(['fullname','name','studentname']), regNo = cv(['registerno','regno','rollno']), acadYear = cv(['academicyear','ay']) || '2025-26', courseType = cv(['coursetype','course']).toUpperCase() || 'UG', branch = cv(['branch']), deptName = cv(['department','dept']), yearStr = cv(['year','studyyear']), className = cv(['class','classname']), section = cv(['section','sec']) || 'A', email = cv(['email','mail']), username = cv(['username','user']), password = cv(['password','pass']) || 'Student@123';
      const rowErrors = [];
      if (!name) rowErrors.push('FullName missing');
      if (!regNo) rowErrors.push('RegisterNo missing');
      if (!deptName) rowErrors.push('Department missing');
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) rowErrors.push('Invalid email');
      if (VALID_COURSE_TYPES.indexOf(courseType) === -1) rowErrors.push(`CourseType "${courseType}" unknown`);
      if (await M.Student.findOne({ regNo })) rowErrors.push(`RegisterNo ${regNo} already exists`);
      if (username && await M.User.findOne({ username: username.toLowerCase() })) rowErrors.push(`Username "${username}" taken`);
      if (rowErrors.length) { skipped++; errors.push({ row: i+2, name: name||'(blank)', issues: rowErrors }); continue; }
      const dept = await M.Department.findOne({ $or: [{ name: new RegExp(deptName, 'i') }, { code: new RegExp(deptName, 'i') }] });
      const cls  = await M.Class.findOne({ name: className }).lean();
      await M.Student.create({ name, regNo, academicYear: acadYear, courseType, branch, deptId: dept?._id, deptName: dept?.name || deptName, classId: cls?._id, className: cls?.name || className, year: yearStr, section, email });
      if (username) {
        const hash = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
        await M.User.create({ name, username: username.toLowerCase(), password: hash, role: 'student', regNo, deptName: dept?.name || deptName, email });
      }
      added++;
    }
    await logAction(req.user._id, req.user.name, req.user.role, 'Bulk Student Upload', `${added} added, ${skipped} skipped`, 'data', 'info', req.ip);
    res.json({ added, skipped, total: rows.length, errors: errors.slice(0, 20), message: `Import complete: ${added} added, ${skipped} skipped` });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ════════════════════════════════════════════════════════
//  TEACHERS
// ════════════════════════════════════════════════════════

app.get('/api/teachers', authMiddleware, async (req, res) => {
  const teachers = await M.User.find({ role: 'teacher', active: true }, '-password').sort({ name: 1 });
  res.json(teachers);
});
app.post('/api/teachers', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { name, firstName, lastName, empId, dept, desig, username, password, email, phone,
      isHOD, hodDeptName, isClassAdvisor, advisorClassName, advisorClassId,
      isTimeTableCoord, ttDeptName, isAdmin, adminRights,
      isWarden, isExamCoordinator, isPlacementCoord, qualifications, experience, joiningDate } = req.body;
    if (!name || !username || !password) return res.status(400).json({ error: 'name, username, password required' });
    const hash = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
    const teacher = await M.User.create({
      name, firstName: firstName||'', lastName: lastName||'',
      empId, dept, desig, username: username.toLowerCase(), password: hash, role: 'teacher',
      email, phone, mustChangePassword: true,
      isHOD: !!isHOD, hodDeptName: hodDeptName||'',
      isClassAdvisor: !!isClassAdvisor, advisorClassName: advisorClassName||'', advisorClassId: advisorClassId||'',
      isTimeTableCoord: !!isTimeTableCoord, ttDeptName: ttDeptName||'',
      isAdmin: !!isAdmin, adminRights: adminRights||[],
      isWarden: !!isWarden, isExamCoordinator: !!isExamCoordinator, isPlacementCoord: !!isPlacementCoord,
      qualifications: qualifications||'', experience: experience||'', joiningDate: joiningDate||''
    });
    const { password: _, ...teacherData } = teacher.toObject();
    await logAction(req.user._id, req.user.name, req.user.role, 'Teacher Added', `${name} (${username}) — initial password set`, 'data', 'info', req.ip);
    res.status(201).json({ ...teacherData, _plainPassword: password });
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/teachers/:id', authMiddleware, adminOnly, async (req, res) => {
  const { password, ...data } = req.body;
  if (password) data.password = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
  const teacher = await M.User.findByIdAndUpdate(req.params.id, data, { new: true }).select('-password');
  await logAction(req.user._id, req.user.name, req.user.role, 'Teacher Updated', teacher?.name, 'data', 'info', req.ip);
  res.json(teacher);
});
app.delete('/api/teachers/:id', authMiddleware, adminOnly, async (req, res) => {
  const teacher = await M.User.findById(req.params.id).lean();
  if (!teacher) return res.status(404).json({ error: 'Teacher not found' });
  await M.UndoLog.create({ collectionName: 'teachers', label: `Teacher: ${teacher.name} (@${teacher.username})`,
    snapshot: teacher, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
  await M.User.findByIdAndDelete(req.params.id);
  await M.Assignment.deleteMany({ teacherId: req.params.id });
  await logAction(req.user._id, req.user.name, req.user.role, 'Teacher Deleted', teacher.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  ATTENDANCE
// ════════════════════════════════════════════════════════

app.get('/api/attendance', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.teacherId) filter.teacherId = req.query.teacherId;
  if (req.query.classId)   filter.classId   = req.query.classId;
  if (req.query.date)      filter.date       = req.query.date;
  if (req.query.from && req.query.to) filter.date = { $gte: req.query.from, $lte: req.query.to };
  res.json(await M.Attendance.find(filter).sort({ date: -1 }).limit(500));
});
app.post('/api/attendance', authMiddleware, async (req, res) => {
  try {
    const existing = await M.Attendance.findOne({ teacherId: req.body.teacherId, classId: req.body.classId, subjectId: req.body.subjectId, date: req.body.date });
    if (existing) {
      const updated = await M.Attendance.findByIdAndUpdate(existing._id, req.body, { new: true });
      await logAction(req.user._id, req.user.name, req.user.role, 'Attendance Updated', `${req.body.className} on ${req.body.date}`, 'attendance', 'info', req.ip);
      return res.json(updated);
    }
    const record = await M.Attendance.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Attendance Marked', `${req.body.className} on ${req.body.date}`, 'attendance', 'info', req.ip);
    res.status(201).json(record);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.get('/api/attendance/unmarked-teachers', authMiddleware, adminOnly, async (req, res) => {
  const today  = new Date(), monday = new Date(today);
  monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const weekDates = Array.from({ length: 5 }, (_, i) => { const d = new Date(monday); d.setDate(monday.getDate() + i); return d.toISOString().split('T')[0]; });
  const assignments = await M.Assignment.find().lean();
  const attendance  = await M.Attendance.find({ date: { $in: weekDates } }).lean();
  const unmarked    = [];
  for (const a of assignments) {
    const markedDates = attendance.filter(att => String(att.teacherId) === String(a.teacherId) && String(att.classId) === String(a.classId) && String(att.subjectId) === String(a.subjectId)).map(att => att.date);
    const missingDays = weekDates.filter(d => !markedDates.includes(d));
    if (missingDays.length > 0) unmarked.push({ ...a, missingDays, missingCount: missingDays.length });
  }
  res.json(unmarked);
});

// ── Live Session Endpoints ──────────────────────────────
app.post('/api/live-session/start', authMiddleware, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Only teachers can start live sessions' });
  const { classId, subjectId, date } = req.body;
  if (!classId || !subjectId || !date) return res.status(400).json({ error: 'classId, subjectId, date required' });
  
  // Close any existing active sessions for this teacher/class
  await M.LiveSession.updateMany({ teacherId: req.user._id, classId, active: true }, { active: false });
  
  const passcode = Math.floor(1000 + Math.random() * 9000).toString(); // 4-digit
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now

  const session = await M.LiveSession.create({
    teacherId: req.user._id, classId, subjectId, date, passcode, expiresAt, active: true, markedStudents: []
  });
  res.status(201).json(session);
});

app.get('/api/live-session/active', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Students only' });
  try {
    // Find student's classId
    const student = await M.Student.findOne({ userId: req.user._id });
    if (!student || !student.classId) return res.json({ active: false });

    // Find active session for this class
    const session = await M.LiveSession.findOne({ classId: student.classId, active: true, expiresAt: { $gt: new Date() } }).populate('subjectId', 'name').lean();
    if (!session) return res.json({ active: false });

    // Check if already marked
    const alreadyMarked = session.markedStudents.some(s => String(s.studentId) === String(student._id));
    
    res.json({ active: true, sessionId: session._id, subjectName: session.subjectId?.name || 'Subject', alreadyMarked });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/live-session/mark', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Students only' });
  const { sessionId, passcode } = req.body;
  
  try {
    const student = await M.Student.findOne({ userId: req.user._id });
    if (!student) return res.status(404).json({ error: 'Student profile not found' });

    const session = await M.LiveSession.findById(sessionId);
    if (!session || !session.active || session.expiresAt < new Date()) {
      return res.status(400).json({ error: 'Session is no longer active' });
    }

    // IP Check
    const settings = await M.Settings.findOne({ key: 'college_ips' });
    const allowed = settings ? settings.value : [];
    let isAllowed = allowed.length === 0; // if empty, allow all
    if (!isAllowed) {
       for (const ip of allowed) {
         if (req.ip.startsWith(ip) || (ip === '::1' && req.ip === '::1') || (ip === '127.0.0.1' && req.ip === '127.0.0.1') || req.ip.includes(ip)) {
           isAllowed = true; break;
         }
       }
    }
    if (!isAllowed) return res.status(403).json({ error: 'Must connect via College Wi-Fi' });

    // Passcode Check
    if (session.passcode !== passcode) {
      return res.status(400).json({ error: 'Incorrect Passcode' });
    }

    // Already marked?
    const alreadyMarked = session.markedStudents.some(s => String(s.studentId) === String(student._id));
    if (alreadyMarked) return res.json({ success: true, message: 'Already marked' });

    session.markedStudents.push({
      studentId: student._id,
      regNo: student.regNo,
      time: new Date(),
      ip: req.ip
    });
    await session.save();

    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/live-session/status/:id', authMiddleware, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Teachers only' });
  const session = await M.LiveSession.findOne({ _id: req.params.id, teacherId: req.user._id });
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json({ active: session.active, expiresAt: session.expiresAt, markedStudents: session.markedStudents });
});

app.post('/api/live-session/end/:id', authMiddleware, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Teachers only' });
  await M.LiveSession.findOneAndUpdate({ _id: req.params.id, teacherId: req.user._id }, { active: false });
  res.json({ success: true });
});

// ════════════════════════════════════════════════════════
//  STUDENT PORTAL  — /api/student/me
// ════════════════════════════════════════════════════════

app.get('/api/student/me', authMiddleware, checkMaintenance, async (req, res) => {
  try {
    if (req.user.role !== 'student') return res.status(403).json({ error: 'Students only' });

    // ── User record
    const user = await M.User.findById(req.user._id).select('-password').lean();
    if (!user) return res.status(404).json({ error: 'User not found' });

    // ── Student profile — try userId first, fall back to regNo then name, auto-link if found
    let student = await M.Student.findOne({ userId: req.user._id }).lean();
    if (!student && user.regNo) {
      student = await M.Student.findOneAndUpdate(
        { regNo: user.regNo },
        { $set: { userId: req.user._id } },
        { new: true }
      ).lean();
    }
    if (!student) {
      student = await M.Student.findOneAndUpdate(
        { name: user.name },
        { $set: { userId: req.user._id } },
        { new: true }
      ).lean();
    }
    if (!student) {
      // No Student profile record at all — return user info with empty attendance so portal loads
      const academic2 = await M.Settings.findOne({ key: 'academic' });
      const minReq2 = academic2?.value?.minAttendance || 75;
      return res.json({
        user: { _id: user._id, name: user.name, username: user.username, email: user.email, lastLogin: user.lastLogin, loginCount: user.loginCount },
        student: { name: user.name, regNo: user.regNo || '—', deptName: user.deptName || '—', className: '—', year: '—', section: '—', academicYear: '—', courseType: '—', branch: '—', email: user.email || '—', bloodGroup: '—', parentContact: '—' },
        attendance: { subjects: [], totalPresent: 0, totalAbsent: 0, totalClasses: 0, overall: 0, minRequired: minReq2 },
      });
    }

    // ── Minimum attendance requirement
    const academic = await M.Settings.findOne({ key: 'academic' });
    const minRequired = academic?.value?.minAttendance || 75;

    // ── All attendance records for this student's class
    const allAttendance = await M.Attendance.find({ classId: student.classId }).lean();

    // ── Aggregate per subject
    const subjectMap = {}; // subjectId → { subjectName, teacherName, present, absent, dates[] }

    for (const rec of allAttendance) {
      const sid = String(rec.subjectId);
      if (!subjectMap[sid]) {
        subjectMap[sid] = {
          subjectId:   sid,
          subjectName: rec.subjectName || 'Unknown',
          teacherName: rec.teacherName || '—',
          present: 0,
          absent:  0,
          total:   0,
          dates:   [],
        };
      }
      const entry = subjectMap[sid];
      // Find this student's record in the attendance doc
      const myRecord = rec.records.find(r =>
        (r.studentId && String(r.studentId) === String(student._id)) ||
        (r.regNo && r.regNo === student.regNo)
      );
      if (myRecord) {
        entry.total++;
        if (myRecord.status === 'present') entry.present++;
        else entry.absent++;
        entry.dates.push({ date: rec.date, status: myRecord.status });
      }
    }

    const subjects = Object.values(subjectMap).map(s => ({
      ...s,
      percentage: s.total > 0 ? Math.round((s.present / s.total) * 100) : 0,
      dates: s.dates.sort((a, b) => a.date.localeCompare(b.date)),
    }));

    // ── Overall totals
    const totalPresent = subjects.reduce((n, s) => n + s.present, 0);
    const totalAbsent  = subjects.reduce((n, s) => n + s.absent,  0);
    const totalClasses = subjects.reduce((n, s) => n + s.total,   0);
    const overall      = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 0;

    res.json({
      user: { _id: user._id, name: user.name, username: user.username, email: user.email, lastLogin: user.lastLogin, loginCount: user.loginCount },
      student,
      attendance: {
        subjects,
        totalPresent,
        totalAbsent,
        totalClasses,
        overall,
        minRequired,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
//  NOTIFICATIONS
// ════════════════════════════════════════════════════════

app.get('/api/notifications', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.user.role === 'teacher') filter.$or = [{ toTeacherId: req.user._id }, { toTeacherId: null, type: { $ne: 'attendance-alert' } }];
  res.json(await M.Notification.find(filter).sort({ time: -1 }).limit(50));
});
app.post('/api/notifications', authMiddleware, async (req, res) => {
  try {
    const notif = await M.Notification.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Notification Sent', req.body.message?.slice(0,80), 'data', 'info', req.ip);
    res.status(201).json(notif);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/notifications/:id', authMiddleware, async (req, res) => {
  const notif = await M.Notification.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (req.body.status === 'Solved' && notif?.grievanceId) await M.Grievance.findByIdAndUpdate(notif.grievanceId, { status: 'Resolved', resolvedAt: new Date(), resolvedBy: req.user.name });
  if (req.body.status === 'Cancelled' && notif?.grievanceId) await M.Grievance.findByIdAndUpdate(notif.grievanceId, { status: 'Cancelled', cancelledAt: new Date() });
  await logAction(req.user._id, req.user.name, req.user.role, 'Notification ' + (req.body.status || 'Updated'), '', 'data', 'info', req.ip);
  res.json(notif);
});

// ════════════════════════════════════════════════════════
//  GRIEVANCES
// ════════════════════════════════════════════════════════

app.get('/api/grievances', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.user.role === 'teacher') filter.teacherId = req.user._id;
  res.json(await M.Grievance.find(filter).sort({ createdAt: -1 }));
});
app.post('/api/grievances', authMiddleware, async (req, res) => {
  try {
    const grievance = await M.Grievance.create({ ...req.body, teacherId: req.user._id, teacherName: req.user.name });
    await M.Notification.create({ type: 'request', from: req.user.name, fromRole: 'Teacher', message: `[Grievance] ${req.body.subject} — ${req.body.detail.slice(0, 100)}`, time: new Date(), priority: 'Normal', grievanceId: grievance._id });
    await logAction(req.user._id, req.user.name, req.user.role, 'Grievance Filed', req.body.subject, 'data', 'info', req.ip);
    res.status(201).json(grievance);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// ════════════════════════════════════════════════════════
//  TIMETABLE
// ════════════════════════════════════════════════════════

app.get('/api/timetable', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.teacherId) filter.teacherId = req.query.teacherId;
  else if (req.user.role === 'teacher') filter.teacherId = req.user._id;
  res.json(await M.Timetable.find(filter).sort({ day: 1, start: 1 }));
});
app.post('/api/timetable', authMiddleware, async (req, res) => {
  try {
    const slot = await M.Timetable.create({ ...req.body, teacherId: req.user._id, teacherName: req.user.name });
    await logAction(req.user._id, req.user.name, req.user.role, 'Timetable Slot Added', `${req.body.day} ${req.body.start}`, 'data', 'info', req.ip);
    res.status(201).json(slot);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/timetable/:id', authMiddleware, async (req, res) => {
  const slot = await M.Timetable.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(slot);
});
app.delete('/api/timetable/:id', authMiddleware, async (req, res) => {
  await M.Timetable.findByIdAndDelete(req.params.id);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  ACTIVITY LOGS
// ════════════════════════════════════════════════════════

app.get('/api/logs', authMiddleware, adminOnly, async (req, res) => {
  const filter = {};
  if (req.query.role)     filter.role     = req.query.role;
  if (req.query.category) filter.category = req.query.category;
  if (req.query.severity) filter.severity = req.query.severity;
  if (req.query.from)     filter.time = { $gte: new Date(req.query.from) };
  if (req.query.to)       filter.time = { ...filter.time, $lte: new Date(req.query.to + 'T23:59:59') };
  const logs = await M.Log.find(filter).sort({ time: -1 }).limit(500);
  res.json(logs);
});
app.post('/api/logs', authMiddleware, async (req, res) => {
  try {
    const { action, details, category } = req.body;
    await M.Log.create({ userId: req.user._id, userName: req.user.name, role: req.user.role, action, details: details||'', category: category||'general', severity:'info', ip: req.ip });
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false }); }
});

app.delete('/api/logs', authMiddleware, adminOnly, async (req, res) => {
  await M.Log.deleteMany({});
  await logAction(req.user._id, req.user.name, req.user.role, 'Logs Cleared', 'All logs deleted', 'settings', 'warning', req.ip);
  res.json({ deleted: true });
});

// GET /api/logs/users — list distinct users who have logs
app.get('/api/logs/users', authMiddleware, adminOnly, async (req, res) => {
  const users = await M.Log.aggregate([
    { $group: { _id: '$userName', role: { $first: '$role' }, count: { $sum: 1 }, lastTime: { $max: '$time' } } },
    { $sort: { lastTime: -1 } }
  ]);
  res.json(users);
});

// GET /api/logs/by-user/:userName — all logs for a specific user
app.get('/api/logs/by-user/:userName', authMiddleware, adminOnly, async (req, res) => {
  const logs = await M.Log.find({ userName: req.params.userName })
    .sort({ time: -1 }).limit(500);
  res.json(logs);
});

// ════════════════════════════════════════════════════════
//  DASHBOARD SUMMARY
// ════════════════════════════════════════════════════════

app.get('/api/dashboard/summary', authMiddleware, adminOnly, async (req, res) => {
  const [students, depts, teachers, classes, pendingNotifs] = await Promise.all([
    M.Student.countDocuments(),
    M.Department.countDocuments(),
    M.User.countDocuments({ role: 'teacher', active: true }),
    M.Class.countDocuments(),
    M.Notification.countDocuments({ status: 'Pending', read: false }),
  ]);
  res.json({ students, depts, teachers, classes, pendingNotifs });
});

// ════════════════════════════════════════════════════════
//  SUBJECTS
// ════════════════════════════════════════════════════════

app.get('/api/subjects', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.deptId) filter.deptId = req.query.deptId;
  res.json(await M.Subject.find(filter).sort({ name: 1 }));
});
app.post('/api/subjects', authMiddleware, adminOnly, async (req, res) => {
  try {
    const subj = await M.Subject.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Subject Added', `${subj.name} (${subj.code})`, 'data', 'info', req.ip);
    res.status(201).json(subj);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/subjects/:id', authMiddleware, adminOnly, async (req, res) => {
  const subj = await M.Subject.findByIdAndUpdate(req.params.id, req.body, { new: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'Subject Updated', subj?.name, 'data', 'info', req.ip);
  res.json(subj);
});
app.delete('/api/subjects/:id', authMiddleware, adminOnly, async (req, res) => {
  const subj = await M.Subject.findById(req.params.id).lean();
  if (subj) {
    await M.UndoLog.create({ collectionName: 'subjects', label: `Subject: ${subj.name} (${subj.code || ''})`,
      snapshot: subj, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.Subject.findByIdAndDelete(req.params.id);
  }
  await logAction(req.user._id, req.user.name, req.user.role, 'Subject Deleted', subj?.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  ASSIGNMENTS
// ════════════════════════════════════════════════════════

app.get('/api/assignments', authMiddleware, async (req, res) => {
  const filter = {};
  if (req.query.teacherId) filter.teacherId = req.query.teacherId;
  else if (req.user.role === 'teacher') filter.teacherId = req.user._id;
  if (req.query.classId) filter.classId = req.query.classId;
  res.json(await M.Assignment.find(filter).sort({ teacherName: 1 }));
});
app.post('/api/assignments', authMiddleware, adminOnly, async (req, res) => {
  try {
    const existing = await M.Assignment.findOne({ teacherId: req.body.teacherId, classId: req.body.classId, subjectId: req.body.subjectId });
    if (existing) return res.status(409).json({ error: 'Assignment already exists' });
    const asgn = await M.Assignment.create(req.body);
    await logAction(req.user._id, req.user.name, req.user.role, 'Assignment Created', `${req.body.subjectName} → ${req.body.className}`, 'data', 'info', req.ip);
    res.status(201).json(asgn);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.delete('/api/assignments/:id', authMiddleware, adminOnly, async (req, res) => {
  await M.Assignment.findByIdAndDelete(req.params.id);
  await logAction(req.user._id, req.user.name, req.user.role, 'Assignment Removed', req.params.id, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  USERS
// ════════════════════════════════════════════════════════

app.get('/api/users', authMiddleware, adminOnly, async (req, res) => {
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  res.json(await M.User.find(filter, '-password').sort({ name: 1 }));
});
app.put('/api/users/:id', authMiddleware, adminOnly, async (req, res) => {
  const { password, ...data } = req.body;
  if (password) data.password = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
  const user = await M.User.findByIdAndUpdate(req.params.id, data, { new: true }).select('-password');
  await logAction(req.user._id, req.user.name, req.user.role, 'User Updated', user?.name, 'data', 'info', req.ip);
  res.json(user);
});
app.delete('/api/users/:id', authMiddleware, adminOnly, async (req, res) => {
  const user = await M.User.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
  await logAction(req.user._id, req.user.name, req.user.role, 'User Deactivated', user?.name, 'data', 'warning', req.ip);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  ADMINS
// ════════════════════════════════════════════════════════
app.get('/api/admins', authMiddleware, adminOnly, async (req, res) => {
  res.json(await M.User.find({ role: 'admin' }, '-password').sort({ name: 1 }));
});
app.post('/api/admins', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { name, firstName, lastName, username, password, email, phone } = req.body;
    if (!name || !username || !password) return res.status(400).json({ error: 'name, username, password required' });
    const hash = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
    const admin = await M.User.create({ name, firstName: firstName||'', lastName: lastName||'', username: username.toLowerCase(), password: hash, role: 'admin', email: email||'', phone: phone||'', mustChangePassword: true, active: true });
    const { password: _, ...adminData } = admin.toObject();
    await logAction(req.user._id, req.user.name, req.user.role, 'Admin Added', `${name} (${username})`, 'data', 'info', req.ip);
    res.status(201).json(adminData);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.put('/api/admins/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { password, ...data } = req.body;
    if (password) data.password = await bcrypt.hash(password, cfg.BCRYPT_ROUNDS);
    const admin = await M.User.findByIdAndUpdate(req.params.id, data, { new: true }).select('-password');
    await logAction(req.user._id, req.user.name, req.user.role, 'Admin Updated', admin?.name, 'data', 'info', req.ip);
    res.json(admin);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
app.delete('/api/admins/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const admin = await M.User.findById(req.params.id).lean();
    if (!admin) return res.status(404).json({ error: 'Admin not found' });
    await M.UndoLog.create({ collectionName: 'admins', label: `Admin: ${admin.name} (@${admin.username})`,
      snapshot: admin, deletedBy: req.user.name, expiresAt: new Date(Date.now() + 10*24*60*60*1000) });
    await M.User.findByIdAndDelete(req.params.id);
    await logAction(req.user._id, req.user.name, req.user.role, 'Admin Deleted', admin.name, 'data', 'warning', req.ip);
    res.json({ deleted: true });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// ════════════════════════════════════════════════════════
//  DB STATS
// ════════════════════════════════════════════════════════

app.get('/api/system/dbstats', authMiddleware, adminOnly, async (req, res) => {
  try {
    const db = mongoose.connection.db;
    const stats = await db.command({ dbStats: 1, scale: 1024 * 1024 });
    const collList = await db.listCollections().toArray();
    const collStats = await Promise.all(collList.map(async c => ({ name: c.name, count: await db.collection(c.name).countDocuments() })));
    res.json({ dbName: stats.db, collections: stats.collections, totalDocs: stats.objects, dataSize: stats.dataSize.toFixed(2), storageSize: stats.storageSize.toFixed(2), indexSize: stats.indexSize ? stats.indexSize.toFixed(2) : '0.00', fsTotalSize: stats.fsTotalSize ? (stats.fsTotalSize/1024/1024).toFixed(0) : null, fsUsedSize: stats.fsUsedSize ? (stats.fsUsedSize/1024/1024).toFixed(0) : null, collStats });
  } catch (err) { res.status(500).json({ error: err.message }); }
});


// ════════════════════════════════════════════════════════
//  MAINTENANCE LOGS (dedicated endpoint)
// ════════════════════════════════════════════════════════
app.get('/api/logs/maintenance', authMiddleware, adminOnly, async (req, res) => {
  const logs = await M.Log.find({ category: 'maintenance' }).sort({ time: -1 }).limit(50);
  res.json(logs);
});

// ════════════════════════════════════════════════════════
//  SERVER INFO (for server logs panel in control)
// ════════════════════════════════════════════════════════
const _serverStartTime = new Date();
const _serverLogs = []; // In-memory ring buffer, max 200 lines

// Intercept console to capture server logs
const _origLog   = console.log.bind(console);
const _origError = console.error.bind(console);
const _origWarn  = console.warn.bind(console);
function _captureLog(level, args) {
  const line = { time: new Date().toISOString(), level, text: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') };
  _serverLogs.push(line);
  if (_serverLogs.length > 200) _serverLogs.shift();
}
console.log   = (...a) => { _captureLog('info',  a); _origLog(...a); };
console.error = (...a) => { _captureLog('error', a); _origError(...a); };
console.warn  = (...a) => { _captureLog('warn',  a); _origWarn(...a); };

app.get('/api/system/serverlogs', authMiddleware, adminOnly, (req, res) => {
  const since = req.query.since ? new Date(req.query.since) : null;
  const logs = since ? _serverLogs.filter(l => new Date(l.time) > since) : _serverLogs.slice(-100);
  res.json({
    logs,
    uptime: Math.floor((Date.now() - _serverStartTime) / 1000),
    startTime: _serverStartTime.toISOString(),
    nodeVersion: process.version,
    env: process.env.NODE_ENV || 'development',
    memMB: Math.round(process.memoryUsage().rss / 1024 / 1024),
  });
});


// ════════════════════════════════════════════════════════
//  SYSTEM HEALTH  (for Overview live stats)
// ════════════════════════════════════════════════════════
app.get('/api/system/health', authMiddleware, adminOnly, async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const dbState = mongoose.connection.readyState;
    const dbStateMap = { 0:'Disconnected', 1:'Connected', 2:'Connecting', 3:'Disconnecting' };
    const [errorCount, warnCount, totalUsers, activeTeachers] = await Promise.all([
      M.Log.countDocuments({ severity: { $in: ['critical','error'] } }),
      M.Log.countDocuments({ severity: 'warning' }),
      M.User.countDocuments({ active: true }),
      M.User.countDocuments({ role: 'teacher', active: true }),
    ]);
    const recentErrors = await M.Log.find({ severity: { $in: ['critical','error','warning'] } })
      .sort({ time: -1 }).limit(limit).lean();
    res.json({
      dbStatus:      dbStateMap[dbState] || 'Unknown',
      dbConnected:   dbState === 1,
      serverUptime:  Math.floor(process.uptime()),
      errorCount, warnCount, totalUsers, activeTeachers, recentErrors,
      memoryMB:      (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1),
      nodeVersion:   process.version,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ════════════════════════════════════════════════════════
//  UNDO LOG  (10-day restorable deletes)
// ════════════════════════════════════════════════════════
app.get('/api/undo', authMiddleware, adminOnly, async (req, res) => {
  try {
    const items = await M.UndoLog.find({ expiresAt: { $gt: new Date() } })
      .sort({ createdAt: -1 }).limit(100).lean();
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/undo/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const entry = await M.UndoLog.findById(req.params.id).lean();
    if (!entry) return res.status(404).json({ error: 'Undo entry not found or expired' });
    const snap = entry.snapshot;
    const { _id, __v, createdAt, updatedAt, ...body } = snap;
    let restored;
    if      (entry.collectionName === 'departments') restored = await M.Department.create(body);
    else if (entry.collectionName === 'classes')     restored = await M.Class.create(body);
    else if (entry.collectionName === 'subjects')    restored = await M.Subject.create(body);
    else if (entry.collectionName === 'students')    restored = await M.Student.create(body);
    else if (entry.collectionName === 'teachers')    restored = await M.User.create(snap);
    else return res.status(400).json({ error: 'Cannot restore collection: ' + entry.collectionName });
    await M.UndoLog.findByIdAndDelete(req.params.id);
    await logAction(req.user._id, req.user.name, req.user.role, 'Undo Restore', entry.label, 'data', 'info', req.ip);
    res.json({ restored: true, label: entry.label });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/undo/:id', authMiddleware, adminOnly, async (req, res) => {
  await M.UndoLog.findByIdAndDelete(req.params.id);
  res.json({ deleted: true });
});

// ════════════════════════════════════════════════════════
//  BACKUP  (full DB snapshot — GDrive upload stub)
// ════════════════════════════════════════════════════════
app.post('/api/system/backup', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [students, teachers, departments, classes, subjects, attendance, assignments] = await Promise.all([
      M.Student.find().lean(),
      M.User.find({ role: 'teacher' }, '-password').lean(),
      M.Department.find().lean(),
      M.Class.find().lean(),
      M.Subject.find().lean(),
      M.Attendance.find().lean(),
      M.Assignment.find().lean(),
    ]);
    const totalDocs = students.length + teachers.length + departments.length
                    + classes.length + subjects.length + attendance.length + assignments.length;
    const backupPayload = {
      meta: { createdAt: new Date().toISOString(), createdBy: req.user.name, totalDocs },
      students, teachers, departments, classes, subjects, attendance, assignments
    };
    const backupPassword = crypto.randomBytes(6).toString('hex').toUpperCase();
    // ─── Stubs (wire these when ready) ──────────────────
    // await uploadToGDrive('backupfolder', backupPassword, JSON.stringify(backupPayload));
    // await sendMail('mainMail', backupPassword, 'EAMS Backup Password', `Your backup password is: ${backupPassword}`);
    // ────────────────────────────────────────────────────
    await logAction(req.user._id, req.user.name, req.user.role, 'System Backup Created',
      `${totalDocs} docs — GDrive upload pending`, 'data', 'info', req.ip);
    res.json({ ok: true, totalDocs, backupPassword, createdAt: backupPayload.meta.createdAt,
      collections: { students: students.length, teachers: teachers.length, departments: departments.length,
        classes: classes.length, subjects: subjects.length, attendance: attendance.length, assignments: assignments.length }
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/system/backup/history', authMiddleware, adminOnly, async (req, res) => {
  try {
    const logs = await M.Log.find({ action: 'System Backup Created' }).sort({ time: -1 }).limit(20).lean();
    res.json(logs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ════════════════════════════════════════════════════════
//  EXPORT DATA  (password-protected, email stub)
// ════════════════════════════════════════════════════════
app.post('/api/system/export', authMiddleware, adminOnly, async (req, res) => {
  try {
    const type = req.body.type || 'all';
    const studentCount = await M.Student.countDocuments();
    let payload;
    if (type === 'all') {
      const [students, teachers, departments, classes, subjects, attendance, assignments] = await Promise.all([
        M.Student.find().lean(), M.User.find({ role:'teacher' }, '-password').lean(),
        M.Department.find().lean(), M.Class.find().lean(), M.Subject.find().lean(),
        M.Attendance.find().lean(), M.Assignment.find().lean(),
      ]);
      payload = { meta: { exportedAt: new Date().toISOString(), exportedBy: req.user.name,
          type, totalStudents: studentCount }, students, teachers, departments, classes, subjects, attendance, assignments };
    } else {
      const dataMap = {
        students:   () => M.Student.find().lean(),
        teachers:   () => M.User.find({ role:'teacher' }, '-password').lean(),
        attendance: () => M.Attendance.find().lean(),
      };
      const data = dataMap[type] ? await dataMap[type]() : [];
      payload = { meta: { exportedAt: new Date().toISOString(), exportedBy: req.user.name,
          type, totalStudents: studentCount }, data };
    }
    const exportPassword = crypto.randomBytes(6).toString('hex').toUpperCase();
    // ─── Stub (wire when ready) ──────────────────────────
    // await exportMail(req.user.email || 'admin', exportPassword, JSON.stringify(payload));
    // ────────────────────────────────────────────────────
    await logAction(req.user._id, req.user.name, req.user.role, 'Data Exported',
      `Type: ${type} — password mailed (stub)`, 'data', 'info', req.ip);
    res.json({ ok: true, payload, exportPassword, totalStudents: studentCount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});


// ── Delete individual log entry by ID ─────────────────
app.delete('/api/logs/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const result = await M.Log.findByIdAndDelete(req.params.id);
    if (!result) return res.status(404).json({ error: 'Log entry not found' });
    res.json({ deleted: true, id: req.params.id });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── 7-day auto-delete for error/warning/critical logs ─
async function cleanupOldErrorLogs() {
  try {
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const result = await M.Log.deleteMany({
      severity: { $in: ['warning', 'critical', 'error'] },
      time: { $lt: cutoff }
    });
    if (result.deletedCount > 0) {
      console.log(`🧹 Auto-cleanup: deleted ${result.deletedCount} error/warning log(s) older than 7 days`);
    }
  } catch (err) {
    console.error('❌ Auto-cleanup error:', err.message);
  }
}

// ── Start Server ──────────────────────────────────────
const PORT = process.env.PORT || cfg.PORT;
app.listen(PORT, () => {
  console.log(`1/3 : 🚀 EAMS API running → http://localhost:${PORT}`);
  console.log(`2/3 :    Environment: ${cfg.NODE_ENV}`);
  // Schedule 7-day log cleanup: run 5s after start, then every 24h
  setTimeout(() => {
    cleanupOldErrorLogs();
    setInterval(cleanupOldErrorLogs, 24 * 60 * 60 * 1000);
  }, 5000);
});
// ── Delete individual log entry by ID ─────────────────
// (placed after listen so it's clear it's an addition)
